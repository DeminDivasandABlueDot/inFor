<?php error_reporting(E_ERROR | E_PARSE); ?>
<?php include 'links.php'?>
<?php include 'connection.php'?>
<html>
<head>
    <title> Infor Marks Display</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>   
<div  align="center">
                <form method = "POST" action="#" id="DropD">
                    Semester:
                    <?php
                    session_start();
                    $sql="SELECT Sem as s FROM marks WHERE USN='".$_SESSION['usn']."' GROUP BY Sem";
                    $res = mysqli_query($con,$sql);

                    echo '<select id="semselect" name="sem">';
                    echo "<option value= '-1' >"."Overall"."</option>";
                    
                    while ($row = mysqli_fetch_array($res)) {
                        echo "<option value='". $row['s'] ."'>".$row['s']."</option>";
                    }
                    echo '</select>';
                    ?>
                    <div id="mDisplay">
                        <?php include 'marks.php'?> 
                         <script>
                            $(function(){
                             $("#DropD").on('change','select', function(ev) {
                               var x = $('#semselect').val();
                               $('#mDisplay').html(x+"something");
                               $.ajax({url:'marks.php',data:"sem="+x, type:'POST' ,success:function(result) {
                                 $("#mDisplay").html(result);
                             }});
                             });
                            });
                         </script>   
                    </div>
		</form>
     <?php
      if(isset($_POST['submit'])){
        if(!empty($_POST['sem'])) {
          $_SESSION['sem'] = $_POST['sem'];
      }
      }
    ?>
</div>
</body>
</html>

