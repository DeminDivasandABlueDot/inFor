<?php include 'links.php'?>
<?php include 'connection.php'?>
<!-- make sem selection dropdown -->
<html>
<head>
    <title> Infor Marks Display</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js">
    $(function(){
        $("#semselect").click(function(){
            //var sem = $("#semselect option:selected").text();
            $('#yes').html("SEM: "+sem);
        });
    });
</script>
<body>   
<div  align="center">
                <form method = "POST" action="#">
                    Semester:
                    <?php
                    session_start();
                    $sql="SELECT Sem as s FROM marks WHERE USN='".$_SESSION['usn']."' GROUP BY Sem";
                    $res = mysqli_query($con,$sql);

                    echo '<select id="semselect" name="sem">';
                    echo "<option value= '-1' >"."Overall"."</option>";
                    
                    while ($row = mysqli_fetch_array($res)) {
                        echo "<option value='". $row['s'] ."'>".$row['s']."</option>";
                    }
                    echo '</select>';
                    ?>
                    <input type="submit" name="submit" value="View">
		</form>
     <?php
      if(isset($_POST['submit'])){
        if(!empty($_POST['sem'])) {
          $_SESSION['sem'] = $_POST['sem'];
      }
      }
    ?>
</div>
</body>
</html>
<?php include 'marks.php' ?>;