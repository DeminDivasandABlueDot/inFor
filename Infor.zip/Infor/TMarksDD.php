<?php include 'connection.php' ?>
<?php include 'links.php' ?>
<html>
    <title> Teacher Drop Down</title>
<div class="row">
    <form method = "POST" action="#" id="DropM">
                    Your Classes:
                    <?php
                    session_start();
                    $sql="SELECT *, CONCAT(Department, Sem, Section, '-', SubID) as classes FROM teacherallo where TeachID = '".$_SESSION['tid']."'";
           
                    $res = mysqli_query($con,$sql);
                    echo '<select id="cselect" name="class">';
                    echo "<option value = -1 >"." ---SELECT--- "."</option>";
                    while ($row = $res->fetch_assoc()) { 
                        echo "<option value= '". $row['classes'] ."'> ".$row['classes']." </option>";
                        
                    }
                    echo '</select>';
                    ?>
                    <div id="mDisplay">
                         <script>
                            $(function(){
                             $("#DropM").on('change','select', function(ev) {
                               var x = $('#cselect').val();
                               $('#mDisplay').html(x+"something");
                               $.ajax({url:'uploadmarks.php',data:"class="+x, type:'POST' ,success:function(result) {
                                 $("#mDisplay").html(result);
                             }});
                             });
                            });
                         </script>   
                    </div>
		</form>
</div>
</html>

