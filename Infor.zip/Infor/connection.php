<?php 

$host="localhost";
$user="root";
$password="";
$db="infor";

$con = new mysqli($host,$user,$password,$db);
?>
