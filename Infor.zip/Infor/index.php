<?php include 'links.php'?>
<?php include 'connection.php'?>
<?php
if(isset($_POST['email'])){
    session_start();
    $_SESSION['email']=$_POST['email'];
    $password=$_POST['password'];
    
    $sql="select * from profile where email='".$_SESSION['email']."'AND password='".$password."' limit 1";
    
    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result)==1){
        echo 'Login Successful';
    }
    else{
        echo 'Incorrect Email or Password';
    }
$getusn="SELECT USN as usn FROM profile where email='".$_SESSION['email']."' limit 1";
$usnval = mysqli_query($con, $getusn);
if(mysqli_num_rows($usnval)==1){
    while($row = $usnval->fetch_assoc()){
        $_SESSION['usn']= $row['usn'];
    }
}
}
?>
<html>
<head>
  <title>Infor Login</title>
</head>
<body>
<div  align="center">
	<!img src="image/login.png"/>
        <h1 align: center> INFOR LOGIN </h1>
		<form method = "POST" action="#">
			<div>
                            Email ID: <input type="email" name="email" placeholder="Email" size="40"/><br/><br/>
			</div>
			<div>
                            Password: <input type="password" name="password" placeholder="Password" size='40' minlength="8"/><br/><br/>
			</div>
			<input type="submit" type="submit" value="LOGIN" class="btn-login"/><br/>
		</form>
</div>

</body>
</html>


