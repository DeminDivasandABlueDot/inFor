<?php include 'links.php'?>
<?php include 'connection.php'?>
<?php include 'calcmarks.php'?>
<html>
<head>
    <title> Infor Marks</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>  
    <div align="center">
<?php
$semval = $_POST['sem'];
if(is_null($semval)){
    $semval = -1;
}
$query= mysqli_query($con,"SELECT MAX(Sem) as maxsem, MIN(Sem) as minsem FROM marks WHERE USN= '".$_SESSION['usn']."'");
if(mysqli_num_rows($query)==1){
    while($row0 = $query->fetch_assoc()){
        $_SESSION['maxsem']= $row0['maxsem']; //max sem for overall
        $minsem = $row0['minsem'];
    }
}

$cgpa = mysqli_query($con,"SELECT CGPA FROM gpa WHERE USN = '".$_SESSION['usn']."' AND Sem = ".$maxsem." limit 1");
        if( mysqli_num_rows($cgpa) > 0){
            while($rows = $cgpa->fetch_assoc()){
            echo "<h4>CGPA = ".$rows['CGPA']."</h4>";
        }
        }
if($semval== -1){
    $semval = $minsem;
    while($semval <= $_SESSION['maxsem']){
        $sgpa = mysqli_query($con,"SELECT SGPA FROM gpa WHERE Sem = ".$semval." AND USN = '".$_SESSION['usn']."' limit 1");
        if( mysqli_num_rows($sgpa) > 0){
            while($rows = $sgpa->fetch_assoc()){
            echo "<h5>SGPA = ".$rows['SGPA']."</h5>";
        }
        }
        $marksval1 = "SELECT * FROM marks WHERE Sem = ".$semval." AND USN = '".$_SESSION['usn']."'";
        $result1= mysqli_query($con,$marksval1);
        if( mysqli_num_rows($result1) > 0){
            echo "<table><tr><th> Semester </th><th> Subject Name </th><th> MSE1</th><th> MSE2</th><th> MSE3</th><th> LA1</th><th> LA2</th><th> CIE</th><th> GRADE</th><th> GRADE POINT</th></tr>";
            while($row = $result1->fetch_assoc()){
            echo "<tr><td>".$row['Sem']."</td><td>".$row['Subname']."</td><td>".$row['MSE1']."</td><td>".$row['MSE2']."</td><td>".$row['MSE3']."</td><td>".$row['LA1']."</td><td>".$row['LA2']."</td><td>".$row['CIE']."</td><td>".$row['SEE_Grade']."</td><td>".$row['Gradept']."</td></tr>";
        }
            echo "</table>"
        . "<br>";
           
    }
    $semval++;
    }  
    /*$marksval1 = "SELECT * FROM marks";
$result1= mysqli_query($con,$marksval1);
if($result1){
    echo "<table><tr><th> Semester </th><th> Subject Name </th><th> MSE1</th><th> MSE2</th><th> MSE3</th><th> LA1</th><th> LA2</th><th> CIE</th><th> GRADE</th><th> GRADE POINT</th></tr>";
    while($row1 = $result1->fetch_assoc()){
        echo "<tr><td>".$row1['Sem']."</td><td>".$row1['Subname']."</td><td>".$row1['MSE1']."</td><td>".$row1['MSE2']."</td><td>".$row1['MSE3']."</td><td>".$row1['LA1']."</td><td>".$row1['LA2']."</td><td>".$row1['CIE']."</td><td>".$row1['SEE_Grade']."</td><td>".$row1['Gradept']."</td></tr>";
    }
    echo "</table>";
}
else{
    echo " Hang in there, buddy. You'll get it. ";
}*/
}
else {
    $sgpa = mysqli_query($con,"SELECT SGPA FROM gpa WHERE Sem = ".$semval." AND USN = '".$_SESSION['usn']."' limit 1");
        if( mysqli_num_rows($sgpa) > 0){
            while($rows = $sgpa->fetch_assoc()){
            echo "<h5>SGPA = ".$rows['SGPA']."</h5>";
        }
        }
 $marksval = "SELECT * FROM marks WHERE Sem = ".$semval." AND USN = '".$_SESSION['usn']."'";
$result= mysqli_query($con,$marksval);
if($result){
    echo "<table><tr><th> Semester </th><th> Subject Name </th><th> MSE1</th><th> MSE2</th><th> MSE3</th><th> LA1</th><th> LA2</th><th> CIE</th><th> GRADE</th><th> GRADE POINT</th></tr>";
    while($row = $result->fetch_assoc()){
        echo "<tr><td>".$row['Sem']."</td><td>".$row['Subname']."</td><td>".$row['MSE1']."</td><td>".$row['MSE2']."</td><td>".$row['MSE3']."</td><td>".$row['LA1']."</td><td>".$row['LA2']."</td><td>".$row['CIE']."</td><td>".$row['SEE_Grade']."</td><td>".$row['Gradept']."</td></tr>";
    }
    echo "</table>";
}
else{
    echo " Hang in there, buddy. You'll get it. ";
}   
}
?>
    </div>
</body>
</html>

