<?php include 'connection.php' ?>

<html>
    <title> Home </title>
</html>

